//
//  MovieData.swift
//  Bhogireddy_Movies
//
//  Created by student on 4/28/22.
//


import Foundation
import UIKit


struct Movie{
    var title : String
    var image : UIImage
    var releasedYear : String
    var movieRating : String
    var boxOffice : String
    var moviePlot : String
    var cast : [String] = []
}

struct Genre{
    
    var category  :  String = ""
    var movies  :  [Movie] = []
}

let genre1 = Genre(category: "Action", movies: [Movie(title: "Uncharted", image: UIImage(named: "Uncharted")!, releasedYear: "2022", movieRating: "6.5", boxOffice: "122M", moviePlot: "ABrothers Sam and Nathan Nate Drake are caught by museum security trying to steal the first map made after the Magellan expedition. The orphanage that houses both boys kicks Sam out. Before he leaves, Sam promises his return to Nate, and leaves him a ring with the inscription Sic Parvis Magna.", cast: ["Tom Holland","Mark Wahlberg","Antonio Banderas"]), Movie(title: "Ambulance", image : UIImage(named: "Ambulance")!, releasedYear: "2022", movieRating: "6.8", boxOffice: "48.1M", moviePlot: "War veteran Will Sharp, desperately in need of $231,000 for his wife Amy's surgery, reaches out to Danny, his adoptive brother and a life-long criminal, who talks him into taking part in a $32 million bank heist. Though initially hesitant, Will agrees after Danny reaffirms that he is doing this for Amy.", cast: ["Jake Gyllenhaal","Eiza González","Garret Dillahunt"]), Movie(title: "The Batman", image: UIImage(named: "The Batman")!, releasedYear: "2022", movieRating: "8.9", boxOffice: "550M", moviePlot: "On Halloween, Gotham City mayor Don Mitchell Jr. is murdered by a man calling himself the Riddler. Reclusive billionaire Bruce Wayne, who has operated for two years as the vigilante Batman, investigates alongside the Gotham City Police Department (GCPD). At the crime scene, lieutenant James Gordon discovers a message that the Riddler left for Batman. Soon after, the Riddler kills commissioner Pete Savage and leaves another message for Batman.", cast: ["Robert Pattinson","Zoë Kravitz","Paul Dano"]),Movie(title: "Infinite", image: UIImage(named: "Infinite")!, releasedYear: "2021", movieRating: "5.4", boxOffice: "120M", moviePlot: "In 1985 Mexico City, Heinrich Treadway tries to escape the authorities and a man, Bathurst. He and his associates, Abel and Leona speak about the Egg which Treadway stole from Bathurst. Treadway tells Abel that if he does not survive, the latter must remember to look inside. He drives off a bridge, jumping from his car in mid-air and onto a crane 150 feet away. However, Treadway watches helplessly as Bathurst arrives and kills Abel and Leona.", cast: ["Mark Wahlberg","Dylan O'Brien","Chiwetel Ejiofor"]),])

let genre2 = Genre(category: "Horror", movies: [Movie(title: "X", image: UIImage(named: "X")!, releasedYear: "2022", movieRating: "6.8", boxOffice: "55M", moviePlot: "In 1979, aspiring pornographic actress Maxine Minx embarks on a road trip through Texas with her producer boyfriend Wayne, fellow actors Bobby-Lynne and Jackson Hole, director RJ and RJ's girlfriend Lorraine to shoot an adult film for the booming theatrical pornography market.", cast: ["Mia Goth","Jenna Ortega","Brittany Snow"]), Movie(title: "You Won't Be Alone", image: UIImage(named: "You Won't Be Alone")!, releasedYear: "2022", movieRating: "6.5", boxOffice: "26M", moviePlot: "You Won't Be Alone is a 2022 internationally co-produced horror film, written and directed by Goran Stolevski, in his directorial debut. It stars Noomi Rapace, Anamaria Marinca, Alice Englert, Carloto Cotta, Félix Maritaud and Sara Klimoska. The film was released in theatres on 1 April 2022.", cast: ["Sara Klimoska","Leontina Bainović","Anamaria Marinca"]), Movie(title: "Umma", image: UIImage(named: "Umma")!, releasedYear: "2022" , movieRating: "6.8",  boxOffice: "10M", moviePlot: "Korean immigrant Amanda and her homeschooled daughter Chrissy “Chris” live on a rural farm, raising bees, selling honey, raising chickens, and living without modern technology as Amanda has an “allergic reaction” to electronics and electricity. She's upset to learn that Chrissy wants to leave the farm in order to pursue college, as Amanda had wanted her to remain on the farm.", cast: ["Sandra Oh" , "Fivel Stewart"])])

let genre3 = Genre(category: "Comedy", movies: [Movie(title: "Dog", image: UIImage(named: "Dog")!, releasedYear: "2022", movieRating: "6.5", boxOffice: "76M", moviePlot: "Jackson Briggs is a former U.S. Army Ranger suffering from PTSD. He is currently working at a deli but is trying to apply for a rotation in Pakistan, but, because of his conditions, he is deemed unfit for service. He attempts to call in favors but is unsuccessful.", cast: ["Channing Tatum","Jane Adams", "Kevin Nash"]), Movie(title: "Free Guy", image: UIImage(named: "Free Guy")!, releasedYear: "2021", movieRating: "7.1", boxOffice: "59.6M", moviePlot: "Guy is a non-player character (NPC) in Free City, a massively multiplayer online role-playing video game (MMORPG) developed by Soonami Studio. Free City’s players are distinguished from NPCs by the sunglasses they wear, and spend their time robbing banks, murdering NPCs or each other, and overall causing mass mayhem.", cast: ["Ryan Reynolds","Jodie Comer","Joe Keery"]), Movie(title: "Sing 2", image: UIImage(named: "Sing 2")!, releasedYear: "2021", movieRating: "7.4", boxOffice: "122M", moviePlot: "Sometime after the events of the first film, Buster Moon is thriving with his new theatre. However, he fails to impress talent scout Suki, who tells him he would not make it in Redshore City. Buster, encouraged by Nana Noodleman, reunites the singers who competed in the first film, with the exception of Mike, and takes them to the city.", cast: ["Matthew McConaughey","Reese Witherspoon","Scarlett Johansson"])])


let genres = [genre1, genre2, genre3]

