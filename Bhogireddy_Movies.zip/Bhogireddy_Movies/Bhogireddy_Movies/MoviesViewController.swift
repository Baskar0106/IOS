//
//  MoviesViewController.swift
//  Bhogireddy_Movies
//
//  Created by student on 4/28/22.
//

import UIKit

class MoviesViewController: UIViewController, UICollectionViewDelegate, UICollectionViewDataSource {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return movieArr.count
        
    }
    
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = movieCollectionViewOutlet.dequeueReusableCell(withReuseIdentifier: "movieCell", for: indexPath) as! MovieCollectionViewCell
        cell.assignMovie(with: movieArr[indexPath.row])
        return cell
    }
    
    
    var head = ""
    var movieArr:[Movie] = []
    
    @IBOutlet weak var movieNameLabel: UILabel!
    
    @IBOutlet weak var movieRatingLabel: UILabel!
    
    @IBOutlet weak var movieBoxOfficeLabel: UILabel!
    
    @IBOutlet weak var movieYearLabel: UILabel!
    
    @IBOutlet weak var moviePlotLabel: UILabel!
    
    @IBOutlet weak var movieCastLabel: UILabel!
    
    @IBOutlet weak var movieCollectionViewOutlet: UICollectionView!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        movieCollectionViewOutlet.delegate = self
        movieCollectionViewOutlet.dataSource = self
        self.title = head
        movieNameLabel.text = "Movie Name: \(movieArr[0].title)"
        
        movieYearLabel.text = "Movie Released Year : \(movieArr[0].releasedYear)"
        
        movieRatingLabel.text = "Movie Rating: \(movieArr[0].movieRating)"
        
        movieBoxOfficeLabel.text = "Box Office Collection: \(movieArr[0].boxOffice)"
        
        moviePlotLabel.text = "Plot: \(movieArr[0].moviePlot)"
        
        var movies : [String] = movieArr[0].cast
        movieCastLabel.text = "Cast: " + movies.joined(separator: ", ")
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        movieNameLabel.text = "Movie Name: \(movieArr[indexPath.row].title)"
        
        movieYearLabel.text = "Movie Released Year : \(movieArr[indexPath.row].releasedYear)"
        
        movieRatingLabel.text = "Movie Rating: \(movieArr[indexPath.row].movieRating)"
        
        movieBoxOfficeLabel.text = "Box Office Collection: \(movieArr[indexPath.row].boxOffice)"
        
        moviePlotLabel.text = "Plot: \(movieArr[indexPath.row].moviePlot)"
        
        var movies : [String] = movieArr[indexPath.row].cast
        movieCastLabel.text = "Cast: " + movies.joined(separator: ", ")
        }

        


    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
