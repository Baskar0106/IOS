//
//  ViewController.swift
//  Bhogireddy_Movies
//
//  Created by student on 4/28/22.
//

import UIKit

class GenreViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return genreArr.count
    }
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var Cell = genreTableView.dequeueReusableCell(withIdentifier: "sectionCell", for: indexPath)
        Cell.textLabel?.text = genreArr[indexPath.row].category
        return Cell
    }
    
    

    @IBOutlet weak var genreTableView: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        genreTableView.delegate = self
        genreTableView.dataSource = self
    }

    var genreArr = genres
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let transition = segue.identifier
        if transition == "movieSegue"{
            let destination = segue.destination as! MoviesViewController
            destination.movieArr = genreArr[genreTableView.indexPathForSelectedRow!.row].movies
            destination.head = genreArr[genreTableView.indexPathForSelectedRow!.row].category
            
            
        }
        
    }
}

