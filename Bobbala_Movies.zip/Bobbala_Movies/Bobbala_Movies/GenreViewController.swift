//
//  ViewController.swift
//  Bobbala_Movies
//
//  Created by student on 4/28/22.
//

import UIKit

class GenreViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return genresArray.count
    }
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var cell = genreTableView.dequeueReusableCell(withIdentifier: "sectionCell", for: indexPath)
        cell.textLabel?.text = genresArray[indexPath.row].category
        return cell
    }
    
    

    @IBOutlet weak var genreTableView: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        genreTableView.delegate = self
        genreTableView.dataSource = self
    }

    var genresArray = genres
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let transition = segue.identifier
        if transition == "movieSegue"{
            let destination = segue.destination as! MoviesViewController
            destination.moviesArray = genresArray[genreTableView.indexPathForSelectedRow!.row].movies
            destination.head = genresArray[genreTableView.indexPathForSelectedRow!.row].category
        }
    }
}

