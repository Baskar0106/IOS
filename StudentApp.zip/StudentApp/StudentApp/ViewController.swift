//
//  ViewController.swift
//  StudentApp
//
//  Created by Bobbala,Bhaskar Venkata Prudhvi on 3/24/22.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

